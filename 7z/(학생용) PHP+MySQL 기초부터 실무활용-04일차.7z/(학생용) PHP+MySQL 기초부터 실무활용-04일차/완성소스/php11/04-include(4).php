<?
    header("Content-Type: text/html; charset=UTF-8");
    include_once('functions.php');

    $num1 = 100;
    $num2 = 200;
    print_h1(sum($num1, $num2));
?>
