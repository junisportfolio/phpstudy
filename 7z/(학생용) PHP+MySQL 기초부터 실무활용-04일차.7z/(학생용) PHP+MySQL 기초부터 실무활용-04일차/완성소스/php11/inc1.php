<?
    echo("<hr />");
    echo("<h1>이 곳은 inc.php 파일의 영역입니다.</h1>");
    echo("<hr />");
?>
