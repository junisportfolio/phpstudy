<?
    function sum($a, $b) {
        return $a+$b;
    }

    function print_h1($str) {
        echo("<h1>".$str."</h1>\n");
    }
?>


