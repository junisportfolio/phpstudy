<?
    header("Content-Type: text/html; charset=UTF-8");

    echo("<h1>01-include(1).php 시작</h1>");

    include('inc1.php');

    echo("<h1>01-include(1).php 끝</h1>");

    include('inc1.php');
?>
